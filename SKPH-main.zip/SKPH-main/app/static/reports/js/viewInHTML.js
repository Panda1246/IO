document.getElementById('back-btn').addEventListener('click', () => {
    window.location.href = '/reports/ui';
});
