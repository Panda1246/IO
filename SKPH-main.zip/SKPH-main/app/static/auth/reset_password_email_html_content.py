RESET_PASSWORD_EMAIL_HTML_CONTENT = """
<p> Hello,</p>
<p> You have requested to reset your password. Please click the link below to reset your password:</p>
<p> <a href="{{ reset_password_url }}">Reset Password</a></p>
<p> If you did not request a password reset, please ignore this email.</p>
"""
