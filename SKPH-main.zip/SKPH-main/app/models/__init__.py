__author__ = 'Wiktor Stępniewski, Wiktor Szewczyk'
